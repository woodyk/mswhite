"""
soul_vault.py - Encrypt or decrypt a vault_memory.json using a passphrase
"""

import base64
import json
import os
from cryptography.fernet import Fernet
import hashlib
import getpass
import sys

VAULT_FILE = "vault_memory.json"

def derive_key(passphrase):
    return base64.urlsafe_b64encode(hashlib.sha256(passphrase.encode()).digest())

def encrypt_vault():
    if not os.path.exists("memory.json"):
        print("No memory.json found.")
        return
    passphrase = getpass.getpass("Enter passphrase: ")
    key = derive_key(passphrase)
    fernet = Fernet(key)

    with open("memory.json", "rb") as f:
        data = f.read()
    encrypted = fernet.encrypt(data)
    with open(VAULT_FILE, "wb") as f:
        f.write(encrypted)
    print("[OK] Encrypted vault_memory.json created.")

def decrypt_vault():
    if not os.path.exists(VAULT_FILE):
        print("No vault_memory.json found.")
        return
    passphrase = getpass.getpass("Enter passphrase: ")
    key = derive_key(passphrase)
    fernet = Fernet(key)

    with open(VAULT_FILE, "rb") as f:
        encrypted = f.read()
    try:
        decrypted = fernet.decrypt(encrypted)
        with open("memory.json", "wb") as f:
            f.write(decrypted)
        print("[OK] memory.json restored from vault.")
    except Exception as e:
        print(f"[ERROR] Decryption failed: {e}")

def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ("encrypt", "decrypt"):
        print("Usage: python soul_vault.py [encrypt|decrypt]")
        return
    if sys.argv[1] == "encrypt":
        encrypt_vault()
    else:
        decrypt_vault()

if __name__ == "__main__":
    main()
