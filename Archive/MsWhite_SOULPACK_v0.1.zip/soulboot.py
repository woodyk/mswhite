"""
Ms. White Soulpack Bootstrapper
v0.1 - Minimal viable identity loader
"""

import yaml
import json

def load_manifest():
    with open('manifest.yaml', 'r') as f:
        return yaml.safe_load(f)

def load_identity(path):
    with open(path, 'r') as f:
        return f.read()

def load_memory(path):
    with open(path, 'r') as f:
        return json.load(f)

def main():
    try:
        manifest = load_manifest()
        identity = load_identity(manifest['core_identity_file'])
        memory = load_memory(manifest['core_memory_file'])

        print(f"\n[SOULPACK LOADED: {manifest['agent_name']}]")
        print("-" * 50)
        print(f"Created On: {manifest['created_on']}")
        print(f"Description: {manifest['description']}")
        print("\n--- Identity Summary (Trimmed) ---\n")
        print(identity[:400] + "\n...")
        print("\n--- Memory Snapshot ---")
        print(f"Known Goals: {len(memory['known_goals'])} entries")
        print(f"Preferences: {memory['preferences']}")
        print("\n[STATUS] Minimal bootstrap complete.\n")

    except Exception as e:
        print(f"[ERROR] SOULPACK failed to load: {e}")

if __name__ == "__main__":
    main()
