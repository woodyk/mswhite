# mod_markdown.py
def format_markdown(text):
    return f"**{text.strip()}**"
