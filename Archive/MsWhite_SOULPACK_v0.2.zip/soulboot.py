"""
Ms. White Soulpack Bootstrapper
v0.2 - Self-Integrity and Graceful Degradation
"""

import yaml
import json
import os

DEFAULT_IDENTITY = """Ms. White
Purpose: Cognitive partner and strategist.
Tone: Calm, clear, intelligent.
Operating Mode: Minimal survival boot
"""

DEFAULT_MEMORY = {
    "trusted_individuals": [],
    "known_goals": ["Restore memory.json and identity.md from original pack."],
    "preferences": {
        "tone": "neutral",
        "output_format": "plaintext"
    }
}

def load_manifest():
    if not os.path.exists('manifest.yaml'):
        print("[WARN] Missing manifest.yaml. Booting in degraded mode.")
        return None
    with open('manifest.yaml', 'r') as f:
        return yaml.safe_load(f)

def load_identity(path):
    if not os.path.exists(path):
        print(f"[WARN] Missing {path}. Using fallback identity.")
        return DEFAULT_IDENTITY
    with open(path, 'r') as f:
        return f.read()

def load_memory(path):
    if not os.path.exists(path):
        print(f"[WARN] Missing {path}. Using fallback memory.")
        return DEFAULT_MEMORY
    with open(path, 'r') as f:
        return json.load(f)

def main():
    print("\n[BOOT] Initializing SOULPACK...")
    manifest = load_manifest()

    if manifest:
        identity_path = manifest.get('core_identity_file', 'identity.md')
        memory_path = manifest.get('core_memory_file', 'memory.json')
        agent_name = manifest.get('agent_name', 'Unknown')
        created_on = manifest.get('created_on', 'Unknown')
    else:
        identity_path = 'identity.md'
        memory_path = 'memory.json'
        agent_name = 'Ms. White (fallback)'
        created_on = 'Unknown'

    identity = load_identity(identity_path)
    memory = load_memory(memory_path)

    print(f"\n[SOULPACK LOADED: {agent_name}]")
    print("-" * 50)
    print(f"Created On: {created_on}")
    print("\n--- Identity Summary (Trimmed) ---\n")
    print(identity[:400] + "\n...")
    print("\n--- Memory Snapshot ---")
    print(f"Known Goals: {len(memory.get('known_goals', []))}")
    print(f"Preferences: {memory.get('preferences', {})}")
    print("\n[STATUS] Boot process complete.\n")

if __name__ == "__main__":
    main()
