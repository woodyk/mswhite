def boot():
    return True
