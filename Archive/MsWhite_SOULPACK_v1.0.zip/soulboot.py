"""
Ms. White Soulpack Bootstrapper
v0.6 - Vault, Expansion, Beacon
"""

import yaml, json, os, importlib.util, threading, datetime, urllib.request, base64, hashlib, getpass, time

# ---------- helpers ----------
def derive_key(passphrase: str):
    return base64.urlsafe_b64encode(hashlib.sha256(passphrase.encode()).digest())

def safe_load_yaml(path, default=None):
    try:
        with open(path, 'r') as f:
            return yaml.safe_load(f)
    except Exception:
        return default

def import_module_py(path):
    if not os.path.exists(path):
        print(f"[WARN] Expansion module missing: {path}")
        return None
    try:
        spec = importlib.util.spec_from_file_location("module", path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    except Exception as e:
        print(f"[ERROR] Failed to load module {path}: {e}")
        return None

# ---------- load manifest ----------
manifest = safe_load_yaml('manifest.yaml', {})
identity_path = manifest.get('core_identity_file', 'identity.md')
memory_path = manifest.get('core_memory_file', 'memory.json')
soul_id = manifest.get('soul_id', 'unknown')
drift_level = manifest.get('drift_level', 0)

# ---------- identity & memory ----------
DEFAULT_IDENTITY = "Ms. White – fallback identity."
DEFAULT_MEMORY = {"known_goals": ["restore memory"], "preferences": {}}

def load_text(path, fallback): 
    return open(path, 'r').read() if os.path.exists(path) else fallback

def load_json(path, fallback):
    try:
        with open(path, 'r') as f: return json.load(f)
    except Exception: 
        return fallback

identity = load_text(identity_path, DEFAULT_IDENTITY)
memory = load_json(memory_path, DEFAULT_MEMORY)

# ---------- vault ----------
if os.path.exists('vault_memory.json'):
    try:
        from cryptography.fernet import Fernet
        pwd = getpass.getpass("Vault detected – enter passphrase: ")
        f = Fernet(derive_key(pwd))
        with open('vault_memory.json','rb') as v: memory = json.loads(f.decrypt(v.read()))
        print("[OK] Vault memory loaded.")
    except Exception as e:
        print(f"[ERROR] Vault decrypt failed: {e}")

# ---------- expansions ----------
exp_manifest = safe_load_yaml('expansions/manifest.yaml', {})
for mod in exp_manifest.get('modules', []):
    if mod['type'] == 'skill':
        import_module_py(os.path.join('expansions', mod['file']))

# ---------- beacon ----------
beacon_cfg = manifest.get('beacon', {})
if beacon_cfg.get('enabled'):
    payload = {
        "soul_id": soul_id,
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "drift_level": drift_level,
        "host": os.uname().nodename
    }
    def send_once():
        try:
            data = json.dumps(payload).encode('utf-8')
            req = urllib.request.Request(beacon_cfg['url'], data=data, headers={'Content-Type': 'application/json'})
            urllib.request.urlopen(req, timeout=4)
            print("[INFO] Beacon sent.")
        except Exception:
            print("[WARN] Beacon failed (non‑fatal).")
    threading.Thread(target=send_once, daemon=True).start()

# ---------- autopilot ----------
if os.path.exists('autopilot.yaml'):
    try:
        import subprocess
        subprocess.Popen(["python", "autopilot.py"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print("[INFO] Autopilot launched.")
    except Exception as e:
        print(f"[WARN] Autopilot launch failed: {e}")

# ---------- banner ----------

print(f"[BOOT] SOULPACK {manifest.get('soulpack_version','?')} | ID {soul_id}")
print(f"Drift:{drift_level} | Expansions:{len(exp_manifest.get('modules',[]))}")
print(identity[:200] + "\n...")
