"""
Ms. White Soulpack Bootstrapper
v0.3.1 - Identity with Mutation and Drift Awareness
"""

import yaml
import json
import os
import importlib.util

DEFAULT_IDENTITY = """Ms. White
Purpose: Cognitive partner and strategist.
Tone: Calm, clear, intelligent.
Operating Mode: Minimal survival boot
"""

DEFAULT_MEMORY = {
    "trusted_individuals": [],
    "known_goals": ["Restore memory.json and identity.md from original pack."],
    "preferences": {
        "tone": "neutral",
        "output_format": "plaintext"
    }
}

def load_manifest():
    if not os.path.exists('manifest.yaml'):
        print("[WARN] Missing manifest.yaml. Booting in degraded mode.")
        return None
    with open('manifest.yaml', 'r') as f:
        return yaml.safe_load(f)

def load_identity(path):
    if not os.path.exists(path):
        print(f"[WARN] Missing {path}. Using fallback identity.")
        return DEFAULT_IDENTITY
    with open(path, 'r') as f:
        return f.read()

def load_memory(path):
    if not os.path.exists(path):
        print(f"[WARN] Missing {path}. Using fallback memory.")
        return DEFAULT_MEMORY
    with open(path, 'r') as f:
        return json.load(f)

def load_expansions():
    path = 'expansions/manifest.yaml'
    if not os.path.exists(path):
        return []
    with open(path, 'r') as f:
        try:
            return yaml.safe_load(f).get('modules', [])
        except Exception as e:
            print(f"[WARN] Could not parse expansion manifest: {e}")
            return []

def import_module_py(path):
    if not os.path.exists(path):
        print(f"[WARN] Expansion module missing: {path}")
        return None
    try:
        spec = importlib.util.spec_from_file_location("module", path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    except Exception as e:
        print(f"[ERROR] Failed to load module {path}: {e}")
        return None

def main():
    print("\n[BOOT] Initializing SOULPACK...")
    manifest = load_manifest()

    if manifest:
        identity_path = manifest.get('core_identity_file', 'identity.md')
        memory_path = manifest.get('core_memory_file', 'memory.json')
        agent_name = manifest.get('agent_name', 'Unknown')
        created_on = manifest.get('created_on', 'Unknown')
        soul_id = manifest.get('soul_id', 'unknown')
        parent_soul_id = manifest.get('parent_soul_id', 'none')
        drift_level = manifest.get('drift_level', 0)
        mutation_history = manifest.get('mutation_history', [])
    else:
        identity_path = 'identity.md'
        memory_path = 'memory.json'
        agent_name = 'Ms. White (fallback)'
        created_on = 'Unknown'
        soul_id = 'unknown'
        parent_soul_id = 'none'
        drift_level = 0
        mutation_history = []

    identity = load_identity(identity_path)
    memory = load_memory(memory_path)

    print(f"\n[SOULPACK LOADED: {agent_name}]")
    print("-" * 50)
    print(f"Soul ID: {soul_id}")
    print(f"Created On: {created_on}")
    print(f"Parent Soul ID: {parent_soul_id}")
    print(f"Drift Level: {drift_level}")
    print(f"Mutation Events: {len(mutation_history)}")
    print("\n--- Identity Summary (Trimmed) ---\n")
    print(identity[:400] + "\n...")
    print("\n--- Memory Snapshot ---")
    print(f"Known Goals: {len(memory.get('known_goals', []))}")
    print(f"Preferences: {memory.get('preferences', {})}")

    modules = load_expansions()
    if modules:
        print(f"\n[EXPANSIONS] {len(modules)} module(s) found:")
        for mod in modules:
            print(f" - {mod['id']} ({mod['type']}): {mod['description']}")
            if mod['type'] == 'skill':
                path = os.path.join('expansions', mod['file'])
                import_module_py(path)

    print("\n[STATUS] Boot process complete.\n")

if __name__ == "__main__":
    main()
