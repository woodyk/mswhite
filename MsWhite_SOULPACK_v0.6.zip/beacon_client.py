"""
beacon_client.py - Non‑blocking heartbeat sender for SOULPACK
"""

import threading, time, json, urllib.request

def _send(url, payload):
    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=4)
    except Exception:
        pass  # silent fail

def start_heartbeat(url: str, payload: dict, interval: int):
    def worker():
        _send(url, payload)  # first beat
        while True:
            time.sleep(interval)
            _send(url, payload)
    t = threading.Thread(target=worker, daemon=True)
    t.start()
